jQuery( document ).ready( function( $ ) {

	var ciColorPicker = $( '.napoleon-colorpckr' );
	ciColorPicker.each( function() {
		$( this ).wpColorPicker();
	} );

} );
