=== napoleon ===
Author: Bitherhood from www.bitherhood.com
Theme page: https://bitherhood.com 
Tags: translation-ready, custom-background, theme-options, custom-menu, threaded-comments, cutsom-posts
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==

An cash on delivery theme for WordPress

== Changelog ==


= 1.5 - 1:00 AM 07/10/2024 =

* FIXED abandon carts issue

= 1.4 - 17th September 2024 =
* FIXED compatibility with woocommerce version 9.3.1 


= 1.3 - 2nd September 2024 =
* ADDED green red border colors to valid invalid inputs respectively  
* FIXED abandon carts issue
* FIXED gif image issue in iOS
* REMOVED Tasheel as bundled plugin from Napoleon
* ADDED confetti effect to thank you page
* ADDED fast thank you page option
* ADDED arabic translation to cities names
* FIXED session error in abandonment carts


= 1.2 - 5th August 2024 =
* ADDED option to hide related products on thank you page
* FIXED email hiding issue in customizer
* ADDED vertical carousel to top bar
* ADDED animation to buy button in the form
* FIXED compatibility with woocommerce version 8.6.0
* FIXED issue with cod form and elementor pages
* FIXED compatibility with bordereau generator plugin


= 1.1 - 27 July 2024 =
* FIXED compatibility with woocommerce version 9.1.4
* REMOVED "most popular" label in radio variations
* ADDED Tasheel as bundled plugin to improve COD Form
* ADDED sticky header with product name in single product pages
* ADDED option to activate radio list for product variations 
* FIXED compatibility with bordereau generator plugin
* ADDED "most popular" label to radio variations in product page
* ADDED email field to cod form
* FIXED displaying free shipping before a state has been selected
* FIXED missing state in order details for orders created with php
* FIXED add to cart issue with variation product types

= 1.0 - 02 FEB 2024 =
* Initial release




